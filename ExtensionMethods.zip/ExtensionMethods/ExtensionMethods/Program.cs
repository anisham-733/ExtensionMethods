﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExtensionMethods;
namespace ExtensionMethods
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 10;
            int result = i.isGreaterThan(10,20,30,50);
            Console.WriteLine(result);
            string res = i.concat("hello", "hi");
            Console.WriteLine(res);
            int g = int.
            

            //isGreaterThan() - not a method of int data type-it is extension method for int data type
            //to use extension method, just use the namespace where it has been declared and defined
            //this keyword is used for binding
        }
    }
}
