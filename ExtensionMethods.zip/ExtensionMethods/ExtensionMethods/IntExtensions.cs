﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethods
{
    public static class IntExtensions
    {
        //define a static class with a static method
        public static int isGreaterThan(this int i, params int[] arr)
        {
            int sum = 0, j; ;
            for(j = 0; j<arr.Length; j++)
            {
                sum += arr[j];
            }
            return sum;
            //return i > value;
        }
        public static string concat(this int i, params string[] arr)
        {
            List<string> list = new List<string>();//generic
            ArrayList arrayList = new ArrayList();//non generic
            //Hashtable
            //Dictionary
            //class type based
            StringBuilder  result = new StringBuilder();
            for(int j = 0; j<arr.Length; j++)
            {
                result.Append($"{arr[j]}");
                
            }
            return result.ToString();
        }
        
    }
    //include extension methods namespace wherever you want to use this extension method
}
